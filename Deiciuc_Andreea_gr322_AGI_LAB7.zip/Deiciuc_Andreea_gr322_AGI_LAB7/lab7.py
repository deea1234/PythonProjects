# Scrieti un program (in Python) care sa determine un punct de pe o curba B-spline
# cubica, in,plan, cu 5 puncte de control, folosind algoritmul lui
# Boor.
class Punct():
    def __init__(self, x, y, ):
        self.x = x
        self.y = y

    def multiply(self, const):
        return Punct(self.x * const, self.y * const)

    def __add__(self, other):
        return Punct(self.x + other.x, self.y + other.y)

    def __sub__(self, other):
        return Punct(self.x - other.x, self.y - other.y)

    def __str__(self):
        return f"({self.x} , {self.y})"


# consola
def puncte_de_control():
    lista_puncte = []
    for i in range(0, 5):
        x = float(input("Dati valoarea coordonatei x: "))
        y = float(input("Dati valoarea coordonatei y: "))
        lista_puncte.append(Punct(x, y))

    return lista_puncte


def noduri():
    lista_noduri = []
    for i in range(0, 9):
        nod = float(input("Introduceti valoarea nodului: "))
        lista_noduri.append(nod)
    return lista_noduri


# fisier
def puncte_de_control_file():
    lista_puncte = []
    with open("punct_de_control.txt", 'r') as f:
        lines = f.readlines()
        for line in lines:
            x = float(line.split(',')[0])
            y = float(line.split(",")[1])
            punct = Punct(x, y)
            lista_puncte.append(punct)
    return lista_puncte


def noduri_file():
    noduri = []
    with open("noduri.txt", 'r') as f:
        lines = f.readlines()
        for line in lines:
            noduri.append(float(line))

    return noduri


def algoritmul_lui_Boor(t, puncte_control, noduri):
    """
    algoritmul lui Boor pentru a determina un punct de pe o curba B-spline cubica
    noduri: vectorul de noduri
    puncte_control: vectorul punctelor de control
    t: valoarea cuprinsa intre t3 si t5
    :return: returneaza r(t) ( punctul de pe curba)
    """
    # gradul curbei
    grad = 3
    k = 0

    # daca k trebuie sa fie mai mic decat numarul de noduri si, t nu trebuie sa apartina intervalului
    while k < len(noduri) - 1 and (noduri[k] < t and t > noduri[k + 1]):
        k += 1

    d = puncte_control

    for r in range(1, grad + 1):
        for i in range(grad, r - 1, -1):
            alpha = ((t - noduri[i + k - grad]) / (noduri[i + 1 + k - r] - noduri[i + k - grad]))
            d[i] = d[i - 1].multiply(1 - alpha).__add__(d[i].multiply(alpha))

    return d[grad]


def meniu():
    print("1.Introduceti date consola:\n"
          "2.Introduceti date din fisier:\n")

    op = int(input("1 sau 2: "))
    if op == 1:
        print("Introduceti cele 5 puncte: ")
        lista_puncte = puncte_de_control()
        print("Introduceti cele 9 noduri")
        list_noduri = noduri()
        print(f"Introduceti t({list_noduri[3]} <= t <= {list_noduri[5]}: ")
        t = float(input("t: "))
        print("Aplicam alboritmul lui Boor pentru a determina un punct de pe curba: \n")
        r_t = algoritmul_lui_Boor(t, lista_puncte, list_noduri)
        print(r_t)
    elif op == 2:
        lista_puncte = puncte_de_control_file()
        lista_noduri = noduri_file()
        print(f"Introduceti t({lista_noduri[3]} <= t <= {lista_noduri[5]}: ")
        t = float(input("t: "))
        print("Aplicam alboritmul lui Boor pentru a determina un punct de pe curba: \n")
        r_t = algoritmul_lui_Boor(t, lista_puncte, lista_noduri)
        print(r_t)

    else:
        print("Optiune gresita!Reincercati!")


def main():
    meniu()


main()
